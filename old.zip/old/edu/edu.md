## About

This is a **solid path** for those of you who want to complete a **Computer Science** course on your own time, **for free**, with courses from the **best universities** in the World.

In our curriculum, we give preference to MOOC (Massive Open Online Course) style courses because these courses were created with our style of learning in mind.

## Motivation & Preparation

Here are two interesting links that can make **all** the difference in your journey.

The first one is a motivational video that shows a guy that went through the "MIT Challenge", which consists of learning the entire **4-year** MIT curriculum for Computer Science in **1 year**.

- [MIT Challenge](https://www.scotthyoung.com/blog/myprojects/mit-challenge-2/)

The second link is a MOOC that will teach you learning techniques used by experts in art, music, literature, math, science, sports, and many other disciplines. These are **fundamental abilities** to succeed in our journey.

- [Learning How to Learn](https://www.coursera.org/learn/learning-how-to-learn)

**Are you ready to get started?**

## Curriculum

- [Introduction to Computer Science](#introduction-to-computer-science)
- [Math (Mathematical Thinking)](#math-mathematical-thinking)
- [Program Design](#program-design)
- [Math (Calculus & Discrete Math)](#math-calculus-and-discrete-math)
- [Algorithms](#algorithms)
- [Programming Paradigms](#programming-paradigms)
- [Software Testing](#software-testing)
- [Math (Calculus)](#math-calculus)
- [Software Architecture](#software-architecture)
- [Theory](#theory)
- [Software Engineering](#software-engineering)
- [Math (Probability)](#math-probability)
- [Computer Architecture](#computer-architecture)
- [Operating Systems](#operating-systems)
- [Computer Networks](#computer-networks)
- [Databases](#databases)
- [Cloud Computing](#cloud-computing)
- [Math (Linear Algebra)](#math-linear-algebra)
- [Cryptography](#cryptography)
- [Security](#security)
- [Compilers](#compilers)
- [Parallel Computing](#parallel-computing)
- [UX Design](#ux-design)
- [Computer Graphics](#computer-graphics)
- [Artificial Intelligence](#artificial-intelligence)
- [Machine Learning](#machine-learning)
- [Natural Language Processing](#natural-language-processing)
- [Big Data](#big-data)
- [Data Mining](#data-mining)
- [Internet of Things](#internet-of-things)
- [Specializations](#specializations)

---

### Introduction to Computer Science

Courses | Duration | Effort
:-- | :--: | :--:
[Introduction to Computer Science - CS50](https://www.edx.org/course/introduction-computer-science-harvardx-cs50x#!)| 12 weeks | 10-20 hours/week

### Math (Mathematical Thinking)

Courses | Duration | Effort
:-- | :--: | :--:
[Effective Thinking Through Mathematics](https://www.edx.org/course/effective-thinking-through-mathematics-utaustinx-ut-9-01x) | 4 weeks | 2-5 hours/week

### Program Design

Courses | Duration | Effort
:-- | :--: | :--:
[How to Code: Systematic Program Design - Part 1](https://www.edx.org/course/how-code-systematic-program-design-part-ubcx-spd1x)| 5 weeks | 8-12 hours/week
[How to Code: Systematic Program Design - Part 2](https://www.edx.org/course/how-code-systematic-program-design-part-ubcx-spd2x)| 5 weeks | 8-12 hours/week
[How to Code: Systematic Program Design - Part 3](https://www.edx.org/course/how-code-systematic-program-design-part-ubcx-spd3x)| 5 weeks | 8-12 hours/week

### Math (Calculus and Discrete Math)

Courses | Duration | Effort
:-- | :--: | :--:
[Calculus One](https://www.coursera.org/learn/calculus1)| 16 weeks | 8-10 hours/week
[Mathematics for Computer Science](https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-042j-mathematics-for-computer-science-spring-2015/index.htm)| 12 weeks | 5 hours/week

### Algorithms

Courses | Duration | Effort
:-- | :--: | :--:
[Algorithms, Part I](https://www.coursera.org/course/algs4partI)| 6 weeks | 6-12 hours/week
[Algorithms, Part II](https://www.coursera.org/course/algs4partII)| 6 weeks |  6-12 hours/week

### Programming Paradigms

Courses | Duration | Effort
:-- | :--: | :--:
[Functional Programming Principles in Scala](https://www.coursera.org/course/progfun)| 7 weeks | 5-7 hours/week
[Object Oriented Programming in Java](https://www.coursera.org/learn/object-oriented-java) | 6 weeks | 4-6 hours/week

### Software Testing

Courses | Duration | Effort
:-- | :--: | :--:
[Software Testing](https://www.udacity.com/course/software-testing--cs258)| 4 weeks | 6 hours/week
[Software Debugging](https://www.udacity.com/course/software-debugging--cs259)| 8 weeks | 6 hours/week

### Math (Calculus)

Courses | Duration | Effort
:-- | :--: | :--:
[Calculus Two: Sequences and Series](https://www.coursera.org/learn/advanced-calculus)| 7 weeks | 9-10 hours/week

### Software Architecture

Courses | Duration | Effort
:-- | :--: | :--:
[Software Architecture & Design](https://www.udacity.com/course/software-architecture-design--ud821)| 8 weeks | 6 hours/week

### Theory

Courses | Duration | Effort
:-- | :--: | :--:
[Intro to Theoretical Computer Science](https://www.udacity.com/course/intro-to-theoretical-computer-science--cs313)| 9 weeks | 6 hours/week

### Software Engineering

Courses | Duration | Effort
:-- | :--: | :--:
[Software Processes and Agile Practices](https://www.coursera.org/learn/software-processes-and-agile-practices)| 4 weeks | 6-8 hours/week

### Math (Probability)

Courses | Duration | Effort
:-- | :--: | :--:
[Introduction to Probability - The Science of Uncertainty](https://www.edx.org/course/introduction-probability-science-mitx-6-041x-0)| 16 weeks | 12 hours/week

### Computer Architecture

Courses | Duration | Effort
:-- | :--: | :--:
[Computer Architecture](https://www.coursera.org/course/comparch)| - | 5-8 hours/week

### Operating Systems

Courses | Duration | Effort
:-- | :--: | :--:
[Operating Systems and System Programming](https://www.youtube.com/view_play_list?p=-XXv-cvA_iBDyz-ba4yDskqMDY6A1w_c)| 10 weeks | 2-3 hours/week

### Computer Networks

Courses | Duration | Effort
:-- | :--: | :--:
[Computer Networks](https://lagunita.stanford.edu/courses/Engineering/Networking-SP/SelfPaced/about)| - | 4–12 hours/week

### Databases

Courses | Duration | Effort
:-- | :--: | :--:
[Databases](https://lagunita.stanford.edu/courses/DB/2014/SelfPaced/about)| 12 weeks | 8-12 hours/week

### Cloud Computing

Courses | Duration | Effort
:-- | :--: | :--:
[Introduction to Cloud Computing](https://www.edx.org/course/introduction-cloud-computing-ieeex-cloudintro-x-0)| 4 weeks | 1 hour/week

### Math (Linear Algebra)

Courses | Duration | Effort
:-- | :--: | :--:
[Linear Algebra - Foundations to Frontiers](https://www.edx.org/course/linear-algebra-foundations-frontiers-utaustinx-ut-5-04x#!)| 15 weeks | 8 hours/week

### Cryptography

Courses | Duration | Effort
:-- | :--: | :--:
[Cryptography I](https://www.coursera.org/course/crypto)| 6 weeks | 5-7 hours/week
[Cryptography II](https://www.coursera.org/course/crypto2)| 6 weeks | 6-8 hours/week

### Security

Courses | Duration | Effort
:-- | :--: | :--:
[Introduction to Cyber Security](https://www.futurelearn.com/courses/introduction-to-cyber-security) | 8 weeks | 3 hours/week

### Compilers

Courses | Duration | Effort
:-- | :--: | :--:
[Compilers](https://lagunita.stanford.edu/courses/Engineering/Compilers/Fall2014/about)| 9 weeks | 6-8 hours/week

### Parallel Computing

Courses | Duration | Effort
:-- | :--: | :--:
[Parallel Computer Architecture and Programming](http://15418.courses.cs.cmu.edu/spring2016/home)| 20 weeks | -

### UX Design

Courses | Duration | Effort
:-- | :--: | :--:
[UX Design for Mobile Developers](https://www.udacity.com/course/ux-design-for-mobile-developers--ud849)| 6 weeks | 6 hours/week

### Computer Graphics

Courses | Duration | Effort
:-- | :--: | :--:
[Computer Graphics](https://www.edx.org/course/computer-graphics-uc-san-diegox-cse167x)| 6 weeks | 12 hours/week

### Artificial Intelligence

Courses | Duration | Effort
:-- | :--: | :--:
[Artificial Intelligence](https://www.edx.org/course/artificial-intelligence-uc-berkeleyx-cs188-1x#!)| 12 weeks | 15 hours/week

### Machine Learning

Courses | Duration | Effort
:-- | :--: | :--:
[Machine Learning](https://www.coursera.org/learn/machine-learning)| 11 weeks | 4-6 hours/week

### Natural Language Processing

Courses | Duration | Effort
:-- | :--: | :--:
[Introduction to Natural Language Processing](https://www.coursera.org/learn/natural-language-processing)| 12 weeks | -

### Big Data

Courses | Duration | Effort
:-- | :--: | :--:
[Introduction to Big Data](https://www.coursera.org/learn/big-data-introduction)| 3 weeks | 5-6 hours/week

### Data Mining

Courses | Duration | Effort
:-- | :--: | :--:
[Pattern Discovery in Data Mining](https://www.coursera.org/course/patterndiscovery) | 4 weeks | 4-6 hours/week

### Internet of Things

Courses | Duration | Effort
:-- | :--: | :--:
[The Internet of Things](https://www.futurelearn.com/courses/internet-of-things)| 4 weeks | 2 hours/week
